//Brian Macias
//This is my own work.
#include <iostream>
#include "Barn.h"


int main() {
	//std::cout << "Hello World!\n";

	Barn b;
	b.feedChickens();
	b.feedCows();
	b.feedHorses();

	return 0;
}